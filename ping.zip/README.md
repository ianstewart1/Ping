## Docs
#### If compiling project as .go file 
Usage: go run goping [Arguments] IP/Hostname 
#### If compiling project as .exe file 
Usage: goping [Arguments] IP/Hostname 

#### Flags
-n : Number of echo requests to send. (default is infinite)\
-w : Timeout in milliseconds to wait for each reply. (default is 5000ms)

